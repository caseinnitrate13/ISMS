class HeaderSidebarComponent extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
            <header id="header" class="header fixed-top d-flex align-items-center">
                <div class="d-flex align-items-center justify-content-between">
                    <a href="../client-side/dashboard.html" class="logo d-flex align-items-center">
                        <img src="../assets/img/whiteLogo.png" alt="">
                        <span class="d-none d-lg-block">VisPro</span>
                    </a>
                    <i class="bi bi-list toggle-sidebar-btn" style="transition: all 0.3s;"></i>
                </div><!-- End Logo -->

                <nav class="header-nav ms-auto">
                    <ul class="d-flex align-items-center">
                        <li class="nav-item dropdown">
                            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                                <i class="bi bi-bell"></i>
                                <span class="badge bg-primary badge-number">4</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                                <li class="dropdown-header">
                                    You have 4 new notifications
                                    <a href="notifications.html"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li class="notification-item">
                                    <i class="bi bi-exclamation-circle text-warning"></i>
                                    <div>
                                        <h4>Lorem Ipsum</h4>
                                        <p>Quae dolorem earum veritatis oditseno</p>
                                        <p>30 min. ago</p>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li class="notification-item">
                                    <i class="bi bi-x-circle text-danger"></i>
                                    <div>
                                        <h4>Atque rerum nesciunt</h4>
                                        <p>Quae dolorem earum veritatis oditseno</p>
                                        <p>1 hr. ago</p>
                                    </div>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li class="dropdown-footer">
                                    <a href="notifications.html">Show all notifications</a>
                                </li>
                            </ul><!-- End Notification Dropdown Items -->
                        </li><!-- End Notification Nav -->

                        <li class="nav-item dropdown pe-3">
                            <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                                <img src="../assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
                                <span class="d-none d-md-block dropdown-toggle ps-2"></span>
                            </a><!-- End Profile Image Icon -->

                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                                <li class="dropdown-header">
                                    <h6></h6>
                                    <span>Web Designer</span>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item d-flex align-items-center" href="users-profile.html"><i class="bi bi-person"></i><span>My Profile</span></a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item d-flex align-items-center" href="guidelines.html"><i class="bi bi-question-circle"></i><span>Guidelines</span></a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item d-flex align-items-center" href="#"><i class="bi bi-box-arrow-right"></i><span>Sign Out</span></a></li>
                            </ul><!-- End Profile Dropdown Items -->
                        </li><!-- End Profile Nav -->
                    </ul>
                </nav><!-- End Icons Navigation -->
            </header><!-- End Header -->

            <!-- ======= Sidebar ======= -->
            <aside id="sidebar" class="sidebar">
                <ul class="sidebar-nav" id="sidebar-nav">
                    <li class="nav-item custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link" href=""../client-side/dashboard.html">
                            <i class="bi bi-grid"></i>
                            <span>Dashboard</span>
                        </a>
                    </li><!-- End Dashboard Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="mycontents.html">
                            <i class="bi bi-collection"></i>
                            <span>My Contents</span>
                        </a>
                    </li><!-- End My Contents Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="subscription.html">
                            <i class="bi bi-star"></i>
                            <span>Subscription</span>
                        </a>
                    </li><!-- End Subscription Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="payment.html">
                            <i class="bi bi-receipt"></i>
                            <span>Payment</span>
                        </a>
                    </li><!-- End Payment Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="notifications.html">
                            <i class="bi bi-bell"></i>
                            <span>Notifications</span>
                        </a>
                    </li><!-- End Notifications Nav -->

                    <li class="nav-heading mt-3">Personal</li>
                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="users-profile.html">
                            <i class="bi bi-person"></i>
                            <span>Account</span>
                        </a>
                    </li><!-- End Account Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="guidelines.html">
                            <i class="bi bi-question-circle"></i>
                            <span>Guidelines</span>
                        </a>
                    </li><!-- End Guidelines Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="contact.html">
                            <i class="bi bi-person"></i>
                            <span>Contact Us</span>
                        </a>
                    </li><!-- End Contact Nav -->

                    <li class="nav-item mt-3 custom-card-hover" style="transition: all 0.3s;">
                        <a class="nav-link collapsed" href="../index.html">
                            <i class="bi bi-box-arrow-right"></i>
                            <span>Log Out</span>
                        </a>
                    </li><!-- End Log Out Page Nav -->
                </ul>
            </aside><!-- End Sidebar -->
        `;

        this.setupNavigation();
    }

    setupNavigation() {
        const navLinks = this.querySelectorAll('.sidebar-nav .nav-link');

        // Highlight the active link based on the current URL when the page loads
        const currentUrl = window.location.pathname.split("/").pop(); // Get current page file name
        
        // Remove 'collapsed' class from all links and set the active state
        navLinks.forEach(link => {
            const linkUrl = link.getAttribute('href');
            if (linkUrl === currentUrl) {
                link.classList.remove('collapsed'); // Remove active class from all other links
            } else {
                link.classList.add('collapsed'); // Add active class to the current link
            }
        });

        // Handle click event to toggle active state
        navLinks.forEach(link => {
            link.addEventListener('click', (event) => {
                // First, add the active class from all nav-links
                navLinks.forEach(navLink => navLink.classList.add('collapsed'));
                
                // remove active class to the clicked link
                event.currentTarget.classList.remove('collapsed');

                // Optional: Log to check if the event is firing
                console.log(`Clicked: ${event.currentTarget.textContent}`);
            });
        });
    }
}

// Define the custom element
customElements.define('header-sidebar-component', HeaderSidebarComponent);


    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
    import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
    import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

    document.addEventListener("DOMContentLoaded", function () {
        const firebaseConfig = {
            apiKey: "AIzaSyAn7_xxeQAhGoOeQ2a7loTMeqBhxu3MJcM",
            authDomain: "vispro-9ef13.firebaseapp.com",
            projectId: "vispro-9ef13",
            storageBucket: "vispro-9ef13.appspot.com",
            messagingSenderId: "693217615576",
            appId: "1:693217615576:web:c90add91c2746f4c5b41ad",
            measurementId: "G-WPYJ56HJ1S"
        };

        const app = initializeApp(firebaseConfig);
        const db = getFirestore(app);
        const auth = getAuth(app);

        async function checkSubscription(userId) {
            const userDocRef = doc(db, "CLIENTS", userId);
            try {
                const userDoc = await getDoc(userDocRef);
                if (userDoc.exists()) {
                    // Process user data
                    const userData = userDoc.data();
                    console.log("User document found:", userData);
                    // Add your logic to handle user data
                    const firstName = userData.firstname;
                    const lastName = userData.lastname;
                    const middleInitial = userData.minit ? `${userData.minit}` : ""; // Middle initial, if available

                    // Construct abbreviated name
                    const abbreviatedName = `${firstName.charAt(0)}. ${lastName}`;
                    // Full name with middle initial (if available)
                    const fullName = `${firstName} ${middleInitial} ${lastName}`;

                    const myContentsLink = document.querySelector('a[href="mycontents.html"]');
                    const paymentLink = document.querySelector('a[href="payment.html"]');
                    const profileNameSpan = document.querySelector('.nav-profile .dropdown-toggle');  // Profile Name Display
                    const profileNameHeader = document.querySelector('.dropdown-header h6');  // Name in dropdown header

                    // Display abbreviated name in the profile
                    profileNameSpan.textContent = abbreviatedName;

                    // Add an event listener to update the dropdown with the full name when clicked
                    const profileDropdown = document.querySelector('.nav-profile');
                    profileDropdown.addEventListener('click', function () {
                      profileNameHeader.textContent = fullName;  // Show full name in dropdown when opened
                    });

                    // Rest of the logic to handle subscription and links
                    const hasSubscription = userData.subscription && userData.subscription !== '';
                    const payStatus = userData.paystatus;
                    const userRole = userData.userrole;

                    console.log("User role:", userRole, "Subscription status:", hasSubscription, "Payment status:", payStatus);

                    // Disable or enable menu items based on user role, subscription status, and payment status
                    if (userRole === "Business Client" || userRole === "Personal Client") {
                        if (!hasSubscription || payStatus === "") {
                            console.log("No subscription or empty paystatus found. Disabling 'My Contents' and 'Payment' links.");
                            myContentsLink.classList.add('disabled-link');
                            paymentLink.classList.add('disabled-link');
                            myContentsLink.style.pointerEvents = 'none';
                            paymentLink.style.pointerEvents = 'none';
                        } else if (payStatus === "Pending") {
                            console.log("User has a subscription but paystatus is 'Pending'. Disabling 'My Contents' but allowing access to 'Payment'.");
                            // Disable 'My Contents' but allow 'Payment'
                            myContentsLink.classList.add('disabled-link');
                            myContentsLink.style.pointerEvents = 'none';

                            paymentLink.classList.remove('disabled-link');
                            paymentLink.style.pointerEvents = 'auto';
                        } else if (payStatus === "Paid") {
                            console.log("User has paid. Enabling access to 'My Contents' and 'Payment'.");
                            // Enable both 'My Contents' and 'Payment' as the user has paid
                            myContentsLink.classList.remove('disabled-link');
                            myContentsLink.style.pointerEvents = 'auto';

                            paymentLink.classList.remove('disabled-link');
                            paymentLink.style.pointerEvents = 'auto';
                        }

                    } else if (userRole === "LGU Client") {
                        console.log("LGU Client detected. No restrictions applied.");
                        const subscription = document.querySelector('a[href="subscription.html"]'); 
                        myContentsLink.classList.remove('disabled-link');
                        paymentLink.classList.remove('disabled-link');
                        subscription.style.display = 'none';
                        paymentLink.style.display = 'none';
                    }

                } else {
                    console.error("User document does not exist.");
                }
            } catch (error) {
                console.error("Error fetching user document:", error);
            }
        }

        function signOutUser() {
            signOut(auth).then(() => {
                localStorage.removeItem('userID'); // Clear user data from localStorage
                console.log("User signed out successfully.");
                window.location.href = 'index.html'; // Redirect to login page
            }).catch((error) => {
                console.error("Error signing out:", error);
            });
        }

        // Check for user authentication on page load
        const userId = localStorage.getItem('userID');
        if (userId) {
            checkSubscription(userId);
        } else {
            console.error("User not authenticated. Redirecting to login.");
            window.location.href = 'index.html';
        }

        // Monitor authentication state
        onAuthStateChanged(auth, (user) => {
            if (user) {
                console.log("Authenticated user ID:", user.uid);
                // You could update the UI or fetch data for the user
            } else {
                console.error("User is not authenticated.");
            }
        });
    });