class AdminHeaderSidebarComponent extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `  
        
        <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/visprologo.png" alt="">
        <span class="d-none d-lg-block">VISPRO</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-black badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success bg-black badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Neca Dulay</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Ronalyn Furio</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/admin.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">Admin</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Marienell Mago</h6>
              <span>Admin</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="org-chart.html">
                <i class="bi bi-gear"></i>
                <span>MTO Organizational Chart</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-login.html">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.html">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->
      

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="# ">
          <i class="bi bi-list-check"></i><span>Registered Accounts</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="reg-lgu.html">
              <i class="ri ri-account-pin-circle-line"></i><span>LGU Accounts</span>
            </a>
          </li>
          <li>
            <a href="reg-business.html">
              <i class="bi bi-briefcase"></i><span>Business & Personal Accounts</span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav-1" data-bs-toggle="collapse" href="#">
          <i class="bi bi-credit-card"></i><span>Subscriptions</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav-1" class="nav-content collapse" data-bs-parent="#sidebar-nav">
          <li>
            <a href="subs-LGU.html">
              <i class="ri ri-account-pin-circle-line"></i><span>LGU Client</span>
            </a>
          </li>
          <li>
            <a href="subs-business.html">
              <i class="bi bi-briefcase"></i><span>Business & Personal Client</span>
            </a>
          </li>
        </ul>
      </li><!-- End Client's Subscription Nav -->
      
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav-2" data-bs-toggle="collapse" href="#">
          <i class="bi bi-play-circle"></i><span>Contents</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav-2" class="nav-content collapse" data-bs-parent="#sidebar-nav">
          <li>
            <a href="content-lgu.html">
              <i class="ri ri-account-pin-circle-line"></i><span>LGU Advertisement</span>
            </a>
          </li>
          <li>
            <a href="content-business.html">
              <i class="bi bi-briefcase"></i><span>Business & Personal Advertisement</span>
            </a>
          </li>
        </ul>
      </li><!-- End Contents Nav -->
      
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav-3" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide-fill"></i><span>Display Screens & Playlist</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav-3" class="nav-content collapse" data-bs-parent="#sidebar-nav">
          <li>
            <a  href="playlist.html">
              <i class="bi bi-play-circle"></i><span>Playlist</span>
            </a>
          </li>
          <li>
            <a href="screen.html">
              <i class="ri ri-artboard-line"></i><span>Screen</span>
            </a>
          </li>
        </ul>
      </li><!-- End Display Screens & Playlist Nav -->
      
     

      <li class="nav-heading">Personal</li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="users-profile.html">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-faq.html">
          <i class="bi bi-question-circle"></i>
          <span>F.A.Q</span>
        </a>
      </li><!-- End F.A.Q Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-contact.html">
          <i class="bi bi-envelope"></i>
          <span>Contact</span>
        </a>
      </li><!-- End Contact Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.html">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-login.html">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-guidelines.html">
          <i class="bi bi-file-earmark"></i>
          <span>Guidelines</span>
        </a>
      </li><!-- End Blank Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->
        `;

        this.setupNavigation();
    }

    setupNavigation() {
        const navLinks = this.querySelectorAll('.sidebar-nav .nav-link');
        const dropdownLinks = this.querySelectorAll('.sidebar-nav .nav-content a');
    
        // Highlight the active link based on the current URL when the page loads
        const currentUrl = window.location.pathname.split("/").pop(); // Get current page file name
        
        // Remove 'collapsed' class from all links and set the active state
        navLinks.forEach(link => {
            const linkUrl = link.getAttribute('href');
            if (linkUrl === currentUrl) {
                link.classList.remove('collapsed'); // Remove active class from all other links
            } else {
                link.classList.add('collapsed'); // Add active class to the current link
            }
        });
    
        // Set the active state for dropdown links
        dropdownLinks.forEach(link => {
            const linkUrl = link.getAttribute('href');
            if (linkUrl === currentUrl) {
                link.classList.add('active'); // Set the active class for the current link
                //  keep the parent dropdown open
                const parentNav = link.closest('.nav-content');
                if (parentNav) {
                    parentNav.classList.add('show'); // Ensure the dropdown stays open
                    const parentLink = parentNav.previousElementSibling;
                    if (parentLink) {
                        parentLink.classList.remove('collapsed'); // Remove the collapsed class from the parent link
                    }
                }
            } else {
                link.classList.remove('active'); // Remove active class from all other links
            }
    
            // Add click event listener to prevent dropdown collapse
            link.addEventListener('click', (event) => {
                event.stopPropagation(); // Prevent the click from bubbling up and collapsing the dropdown
            });
        });
    }
}

// Define the custom element
customElements.define('admin-header-sidebar-component', AdminHeaderSidebarComponent);